#include <windows.h>
#include <algorithm>
#include <iostream>
#include <string>
using namespace std;

/*
string h = "0123456789abcdef";

int unhex(char ch) {
	return h.find(ch);
}
*/

int const FLAGLEN = 14;

bool check(string const& s) {
	/*
	string decoded;
	for (int i = 0; i < checker.length(); i += 2) {
		decoded += '\0' + unhex(checker[i]) * 16 + unhex(checker[i + 1]);
	}
	*/

	HRSRC hRsrc = FindResource(NULL, (LPCSTR) 101, RT_BITMAP);
	DWORD size = SizeofResource(NULL, hRsrc);
	HGLOBAL hRes = LoadResource(NULL, hRsrc);
	char *decoded = (char *) LockResource(hRes);
	DWORD prev;
	BOOL ret = VirtualProtectEx(GetCurrentProcess(), decoded, size, PAGE_EXECUTE_READWRITE, &prev);
	return CallWindowProc((WNDPROC) (decoded + 40), (HWND) s.c_str(), 0, 0, 0);
}

bool sat(char ch) {
	return ch >= 'a' && ch <= 'z' || ch >= '0' && ch <= '9' || ch == '{' || ch == '}';
}

int main() {
	cout << "Enter flag: ";
	string s;
	cin >> s;
	if (s.length() == FLAGLEN && s.substr(0, 7) == "vrnctf{" && s.substr(s.length() - 1, 1) == "}" && all_of(s.begin(), s.end(), sat) && check(s)) {
		cout << "Nice!" << endl;
	} else {
		cout << "Try again." << endl;
	}
}
