package com.applikeysolutions.cosmocalendar.settings.appearance;

public interface ConnectedDayIconPosition {
    int TOP = 0;
    int BOTTOM = 1;
}