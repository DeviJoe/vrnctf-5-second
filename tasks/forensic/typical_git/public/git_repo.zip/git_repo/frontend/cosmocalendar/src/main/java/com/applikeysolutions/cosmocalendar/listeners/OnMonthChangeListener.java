package com.applikeysolutions.cosmocalendar.listeners;

import com.applikeysolutions.cosmocalendar.model.Month;

public interface OnMonthChangeListener {

    void onMonthChanged(Month month);
}
