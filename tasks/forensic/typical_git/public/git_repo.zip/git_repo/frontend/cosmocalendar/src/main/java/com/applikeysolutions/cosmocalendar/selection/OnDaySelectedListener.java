package com.applikeysolutions.cosmocalendar.selection;

public interface OnDaySelectedListener {
    void onDaySelected();
}
