package com.applikeysolutions.cosmocalendar.settings.date;

public interface DateInterface {

    int getFirstDayOfWeek();

    void setFirstDayOfWeek(int firstDayOfWeek);
}
