package com.applikeysolutions.cosmocalendar.selection.selectionbar;

public interface SelectionBarItem {

}
