package com.applikeysolutions.cosmocalendar.view.delegate;

import com.applikeysolutions.cosmocalendar.view.CalendarView;

public class BaseDelegate {

    protected CalendarView calendarView;
}
