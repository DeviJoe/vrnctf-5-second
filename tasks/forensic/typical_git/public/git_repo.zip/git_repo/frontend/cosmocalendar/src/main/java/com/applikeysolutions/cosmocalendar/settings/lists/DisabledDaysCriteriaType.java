package com.applikeysolutions.cosmocalendar.settings.lists;

public enum DisabledDaysCriteriaType {
    DAYS_OF_MONTH,
    DAYS_OF_WEEK
}
