package com.applikeysolutions.cosmocalendar.utils;

public final class Constants {
    public static final int DAYS_IN_WEEK = 7;
    public static final String DAY_NAME_FORMAT = "EEEEE";
}
