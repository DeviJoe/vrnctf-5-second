package com.applikeysolutions.cosmocalendar.utils;

public enum DayFlag {
    DISABLED,
    WEEKEND,
    FROM_CONNECTED_CALENDAR
}
