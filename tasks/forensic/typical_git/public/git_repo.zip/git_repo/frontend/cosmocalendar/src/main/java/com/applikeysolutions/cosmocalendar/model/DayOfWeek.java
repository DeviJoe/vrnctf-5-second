package com.applikeysolutions.cosmocalendar.model;

import java.util.Date;

public class DayOfWeek extends Day {

    public DayOfWeek(Date date) {
        super(date);
    }
}
