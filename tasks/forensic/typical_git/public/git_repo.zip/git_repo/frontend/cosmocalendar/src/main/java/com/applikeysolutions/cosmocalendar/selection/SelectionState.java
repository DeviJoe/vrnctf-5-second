package com.applikeysolutions.cosmocalendar.selection;

public enum SelectionState {
    START_RANGE_DAY_WITHOUT_END,
    START_RANGE_DAY,
    END_RANGE_DAY,
    RANGE_DAY,
    SINGLE_DAY
}
