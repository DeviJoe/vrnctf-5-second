package com.applikeysolutions.cosmocalendar.dialog;

import com.applikeysolutions.cosmocalendar.model.Day;

import java.util.List;

public interface OnDaysSelectionListener {
    void onDaysSelected(List<Day> selectedDays);
}
