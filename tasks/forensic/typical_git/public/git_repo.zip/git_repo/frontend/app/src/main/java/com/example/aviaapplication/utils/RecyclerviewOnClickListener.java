package com.example.aviaapplication.utils;

public interface RecyclerviewOnClickListener {
    void onRecycleViewCLick(int position);
}
