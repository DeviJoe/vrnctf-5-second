package com.example.aviaapplication.api.models;

public class Passenger {
    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
