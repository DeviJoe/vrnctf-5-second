package com.example.aviaapplication.utils;

import android.content.Intent;

public interface ActivityNavigation {
    void startActivityForResult(Intent intent, int requestCode);
}
