package com.example.aviaapplication.utils;

public interface Consumer<T> {
    void invoke(T param);
}
